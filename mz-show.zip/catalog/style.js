function showAnswer(){
    document.querySelector(".question-small-info").classList.remove("show-question");
}

function hideAnswer(){
    document.querySelector(".question-small-info").classList.add("show-question");
}

function showMoreInfo(){
    if (document.querySelector("#garanty-block").classList.contains('hide-garanty')){
            document.querySelector("#garanty-block").classList.remove("hide-garanty");
            document.querySelector("#garanty-block").classList.add("show-garanty");
            setTimeout(() => {
                document.querySelector("#garanty-block").style="opacity: 1;";
            }, 250);
    }else {
        document.querySelector("#garanty-block").style="opacity: 0;";
        setTimeout(() => {
            document.querySelector("#garanty-block").classList.remove("show-garanty");
            document.querySelector("#garanty-block").classList.add("hide-garanty");
        }, 250);
    }

}