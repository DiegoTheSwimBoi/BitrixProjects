<?
$sSectionName = "Регистрация";
$arDirProperties = array(

);
?>