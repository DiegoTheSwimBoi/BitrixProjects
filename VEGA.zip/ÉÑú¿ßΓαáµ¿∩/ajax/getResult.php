<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
CModule::IncludeModule("sale");
$user_id = $_GET["user_id"];

$arFields = [];
$arIds=[];

$db_props = CSaleOrderProps::GetList(
    array(),
    array(
        "NAME" => ["ИНН", "Название компании", "Телефон"],
        "PERSON_TYPE_ID" => 6
    ),
    false,
    false,
    array("ID", "NAME")
);

while ($res = $db_props->GetNext()){
    $arIds[]=$res;
}



if (isset($user_id)) {
    $rsUser = CUser::GetByID($user_id);
    $arUser = $rsUser->Fetch();

    foreach ($arIds as $value) {
        switch ($value["NAME"]) {
            case "ИНН":
                $arFields[$value["ID"]]=$arUser["UF_INN"];
                break;
            case "Название компании":
                $arFields[$value["ID"]]=$arUser["WORK_COMPANY"];
                break;
            case "Телефон":
                $arFields[$value["ID"]]=$arUser["WORK_PHONE"];
            break;
        }
    }

}
header("Content-type: application/json; charset=utf-8");
echo json_encode(['isSuccess' => true, 'FORM_INPUTS' => $arFields]);