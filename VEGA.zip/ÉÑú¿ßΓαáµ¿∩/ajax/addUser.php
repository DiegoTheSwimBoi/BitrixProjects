<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
//require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_after.php');
CModule::IncludeModule("form");
CModule::IncludeModule("crm");

use Bitrix\Main\Authentication\ApplicationPasswordTable;


if (isset($_POST)) {
    $form_id = $_POST["form"];
    $result = $_POST["result"];
    $form_result = $_POST["form_result"];

    if ($form_result == "addok") {
        CForm::GetResultAnswerArray(
            $form_id,
            $arrColumns,
            $arrAnswers,
            $arrAnswersVarname,
            array("RESULT_ID" => $result)
        );
        $company = "";
        $name = "";
        $last_name = "";
        $second_name = "";
        $phone = "";
        $email = "";
        $inn = "";

        foreach ($arrAnswersVarname as $arItems) {
            foreach ($arItems as $arItem) {
                switch ($arItem[0]["TITLE"]) {
                    case "Компания":
                        $company .= $arItem[0]["USER_TEXT"];
                        break;
                    case "Фамилия":
                        $last_name .= $arItem[0]["USER_TEXT"];
                        break;
                    case "Отчество":
                        $second_name .= $arItem[0]["USER_TEXT"];
                        break;
                    case "Имя":
                        $name .= $arItem[0]["USER_TEXT"];
                        break;
                    case "Телефон контактного лица":
                        $phone .= $arItem[0]["USER_TEXT"];
                        break;
                    case "E-mail":
                        $email .= $arItem[0]["USER_TEXT"];
                        break;
                    case "ИНН":
                        $inn .= $arItem[0]["USER_TEXT"];
                    break;
                }
            }
        }

        $us_message = "";

        $rsUser = CUser::GetByLogin($inn);
        $randomString = '';


        if (!$arUser = $rsUser->Fetch()) {
            $randomString .= \Bitrix\Main\Security\Random::getString(15, true);
            $user = new CUser;

            $arFields = array(
                "NAME" => $name,
                "LAST_NAME" => $last_name,
                "SECOND_NAME" => $second_name,
                "EMAIL" => $email,
                "LOGIN" => $inn,
                "ACTIVE" => "N",
                "GROUP_ID" => 17,
                "PASSWORD" => $randomString,
                "CONFIRM_PASSWORD" => $randomString,
                "UF_DISTRICT" => $randomString,
                "UF_INN" => $inn,
                "WORK_PHONE" => $phone,
                "WORK_COMPANY" => $company,
                "LID"=>"s2"
            );
            $user->Add($arFields);

            $arEventFields = [
                'EMAIL' => $email
            ];

            CEvent::Send("NEW_USER", SITE_ID, $arEventFields);

            $us_message .= '<p class="fs-3">Ваша регистрация прошла успешно.<br>Ожидайте подтверждение на электронную почту</p>';

        } else {
            $us_message .= '<p>Пользователь с таким ИНН уже есть на сайте</p>';
        }

        header("Content-type: application/json; charset=utf-8");
        echo json_encode(['isSuccess' => true, 'USER_MESSAGE' => $us_message]);


    }

}



