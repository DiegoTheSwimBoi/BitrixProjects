<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
require_once($_SERVER['DOCUMENT_ROOT'] . '/bitrix/modules/main/include/prolog_after.php');
CModule::IncludeModule("crm");


if (isset($_POST)) {
    $leadId = str_replace(' ', '', $_POST['lead_id']);

    $lead = CCrmLead::GetByID($leadId);

    if ($lead) {
        $inn='';
        $userList = CUser::GetList($by = "id", $order = "asc", ["NAME" =>$lead["NAME"],"SECOND_NAME"=>$lead["SECOND_NAME"],"LAST_NAME"=>$lead["LAST_NAME"],"ACTIVE"=>"N"]);
        while ($arUser = $userList->Fetch()) {
            if ($arUser["ACTIVE"] != "Y") {
                $inn = $arUser["LOGIN"];
                $password = $arUser["UF_DISTRICT"];
                $user = new CUser;
                $user->Update($arUser["ID"], ["ACTIVE" => "Y", "UF_DISTRICT" => "", "LID" => "s2"]);
                CUser::SendUserInfo($arUser["ID"], SITE_ID, "Ваш пароль:" . $password, false, "USER_INFO");
            }
        }

        if ($lead["COMPANY_ID"]) {

            $requisiteFields = array(
                "ENTITY_TYPE_ID" => 4,
                "ENTITY_ID" => $lead["COMPANY_ID"],
                "NAME" => $lead["COMPANY_TITLE"],
                "PRESET_ID" => 2,
                "RQ_COMPANY_NAME" => $lead["COMPANY_TITLE"],
                "RQ_COMPANY_FULL_NAME" => $lead["COMPANY_TITLE"],
                "RQ_INN" => $inn,
                "RQ_KPP" => "",
				"ASSIGNED_BY_ID"=>52
            );
            $requisiteEntity = new Bitrix\Crm\EntityRequisite();
            $resultRequisit = $requisiteEntity->add($requisiteFields);
            $requisitID = $resultRequisit->GetID();
        }
        if ($lead["CONTACT_ID"]) {
            $requisiteFields = array(
                'ENTITY_TYPE_ID' => 3,//3 - is contact in CRest::call('crm.enum.ownertype');
                'ENTITY_ID' => $lead["CONTACT_ID"], //contact id
                'PRESET_ID' => 2,
                'TITLE' => implode(' ', [$lead["NAME"], $lead["LAST_NAME"]]),
                'ACTIVE' => 'Y',
                'NAME' => $lead["NAME"],
                'RQ_INN' => $inn,
                "RQ_FIRST_NAME" => $lead["NAME"],
                "RQ_SECOND_NAME" => $lead["SECOND_NAME"],
                "RQ_LAST_NAME" => $lead["LAST_NAME"],
				"ASSIGNED_BY_ID"=>52
            );
            $requisiteEntity = new Bitrix\Crm\EntityRequisite();
            $resultRequisit = $requisiteEntity->add($requisiteFields);
            $requisitID = $resultRequisit->GetID();
        }
		
		$new_lead = new CCrmLead();
		$arField["ASSIGNED_BY_ID"]=52;
		$new_lead->Update($lead["ID"],$arField);
		
		$oContact = new \CCrmContact();
		$oContact->update($lead["CONTACT_ID"],$arField);
		
		$oCompany = new \CCrmCompany();
		$oCompany->update($lead["COMPANY_ID"],$arField);
		
    }
}

