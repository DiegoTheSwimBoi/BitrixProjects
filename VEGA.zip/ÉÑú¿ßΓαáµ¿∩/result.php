<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
CJSCore::Init(array('ajax'));
?>
    <div class="form-center">
        <div class="bx-authform p-2 p-md-5 w-50 h-50">
            <p class="message text-center fs-3"></p>
        </div>
    </div>
<script>
    document.addEventListener("DOMContentLoaded", function(event) {
        const params = new URLSearchParams(document.location.search);


        if (params.size<3){
            document.location.href="/";
        }

        const web_form_id = params.get("WEB_FORM_ID");
        const result = params.get("RESULT_ID");
        const form_result = params.get("formresult");



        BX.ajax({
            url: '/local/ajax/addUser.php',
            data: {
                form:web_form_id,
                result:result,
                form_result:form_result
            },
            method: 'POST',
            dataType: 'json',
            timeout: 10,
            onsuccess: function( res ) {
                console.log(res);
                document.querySelector(".message").innerHTML=res.USER_MESSAGE;
            },
            onfailure: e => {
                //console.error( e )
            }
        })

    });
</script>
<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>