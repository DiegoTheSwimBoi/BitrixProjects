<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Sale\Location;
use Bitrix\Sale\Basket;

Bitrix\Main\Loader::includeModule("sale");
Bitrix\Main\Loader::includeModule("catalog");

$arResult = [];


// BASKET-SECTION!!!


$basket = \Bitrix\Sale\Basket::loadItemsForFUser(
    \Bitrix\Sale\Fuser::getId(),
    \Bitrix\Main\Context::getCurrent()->getSite()
);


$arResult["TOTAL_WEIGHT"] = $basket->getWeight();

$noBooks = true;

$dbRes = \Bitrix\Sale\Basket::getList(
    [
        'select' => ['ID', 'PRODUCT_ID', 'NAME', 'QUANTITY', 'PRICE', 'CURRENCY', "DETAIL_PAGE_URL", "MEASURE_CODE"],
        'filter' => [
            '=FUSER_ID' => \Bitrix\Sale\Fuser::getId(),
            '=ORDER_ID' => NULL,
            '=LID' => \Bitrix\Main\Context::getCurrent()->getSite(),
            '=CAN_BUY' => 'Y',
        ]
    ]
);

$arrayParentSections = [];

while ($item = $dbRes->fetch()) {

    $res = CIBlockElement::GetList(array(), ["IBLOCK_ID" => 4, "ID" => $item["PRODUCT_ID"]], false, array("nPageSize" => 50), ["IBLOCK_SECTION_ID", "PREVIEW_PICTURE"]);
    while ($ob = $res->GetNextElement()) {
        $arFields = $ob->GetFields();
        $item["PICTURE"] = CFile::GetPath($arFields["PREVIEW_PICTURE"]) ?: "/upload/resize_cache/webp/local/templates/bitlate_food/images/no_photo.webp";
        $item["QUANTITY"] = (int)$item["QUANTITY"];

        $measureList = \CCatalogMeasure::getList(array(), array("CODE" => $item["MEASURE_CODE"]), false, false, array("SYMBOL_RUS"));
        $measure = $measureList->fetch();
        if ($measure) {
            $item["MEASURE_TEXT"] = $measure["SYMBOL_RUS"];
        }

        $list = CIBlockSection::GetList(
            array("SORT" => "ASC"),
            array("ID" => $arFields["IBLOCK_SECTION_ID"]),
            false,
            array("IBLOCK_SECTION_ID"));
        while ($ar_result = $list->GetNext()) {
            $arrayParentSections[] = $ar_result["IBLOCK_SECTION_ID"];
        }


        switch ($arFields["IBLOCK_SECTION_ID"]) {
            case 221:
                if (in_array("YARMARKA", $arParams['PRODUCT_SECTION_TYPE'])) {
                    $arResult["ROWS"]["ITEMS"]["YARMARKA"][] = $item;
                }
                break;
            case 222:
                if (in_array("PAVILION", $arParams['PRODUCT_SECTION_TYPE'])) {
                    $arResult["ROWS"]["ITEMS"]["PAVILION"][] = $item;
                }
                break;
            default:
                if (in_array("DEFAULT", $arParams['PRODUCT_SECTION_TYPE'])) {
                    $arResult["ROWS"]["ITEMS"]["MARKET"][] = $item;
                }
                break;
        }
    }

    $arResult["CURRENCY"] = $item["CURRENCY"];
    $arResult["TOTAL_PRICE"] += $item["PRICE"] * $item["QUANTITY"];
    $arResult["COUNT"] += 1;
}

if (in_array(227, $arrayParentSections)) {
    $noBooks = false;
}


if ((int)$arParams["BASKET_MIN_SUM"] >= $arResult["TOTAL_PRICE"]) {
    $arResult["ERROR"]["MIN_SUM"] = "Минимальная сумма заказа от " . CurrencyFormat($arParams["BASKET_MIN_SUM"], $arResult["CURRENCY"]);
}


$arResult["TOTAL_PRICE_FORMATTED"] = CurrencyFormat($arResult["TOTAL_PRICE"], $arResult["CURRENCY"]);


// USER Profile


$db_sales = CSaleOrderUserProps::GetList(
    array("DATE_UPDATE" => "DESC"),
    array("USER_ID" => $USER->GetID())
);
while ($ar_sales = $db_sales->Fetch()) {
    $arResult["PROFILE"][] = $ar_sales;
}

$db_propVals = CSaleOrderUserPropsValue::GetList(array("ID" => "ASC"), array("USER_PROPS_ID" => $arResult["PROFILE"][0]["ID"]));
while ($arPropVals = $db_propVals->Fetch()) {
    if ($arPropVals["PROP_CODE"] == "ZIP") {
        $zip = (int)$arPropVals["VALUE"];
        $zip_set = number_format($zip, 0, '', ' ');
        $arResult["PROFILE_FIELDS"][] = ["PROP_CODE" => "ZIP", "VALUE" => $zip_set, "PLACEHOLDER" => "Индекс подставится автоматически после выбора города", "DISABLED" => true];
    } elseif ($arPropVals["PROP_CODE"] == "CITY") {
        $city_location = CSaleLocation::GetByID($arPropVals["VALUE"]);
        $arResult["PROFILE_FIELDS"][] = ["PROP_CODE" => "CITY", "VALUE" => $city_location["CITY_NAME"], "CITY_CODE" => $city_location["CODE"]];
    } else {
        $arResult["PROFILE_FIELDS"][] = ["PROP_CODE" => $arPropVals["PROP_CODE"], "VALUE" => $arPropVals["VALUE"]];
    }

}

$properties = \Bitrix\Sale\Internals\OrderPropsTable::getList([
    'select' => ['*'],
    'filter' => ['ENTITY_REGISTRY_TYPE' => 'ORDER', "PERSON_TYPE_ID" => 2],
])->fetchAll();

foreach ($properties as $property) {
    $arResult['FIELDS'][] = $property;
}

array_pop($arResult["FIELDS"]);


// PAYMENT


$paySystemResult = \Bitrix\Sale\PaySystem\Manager::getList(array(
    'filter' => array(
        'ACTIVE' => 'Y',
        'ID' => $arParams["PAYMENT_SECTION"]
    )
));


while ($paySystem = $paySystemResult->fetch()) {
    if ($noBooks) {
        if (!in_array("Рассрочка", $paySystem) || ($arResult["TOTAL_PRICE"] >= 10000 && $arResult["TOTAL_PRICE"] <= 40000)) {
            $arResult['PAY_SYSTEM'][] = $paySystem;
        }
    } else {
        if (!in_array("Robokassa", $paySystem) || !in_array("Рассрочка", $paySystem)) {
            $arResult['PAY_SYSTEM'][] = $paySystem;
        }
    }
}

$arResult['FORM_INPUTS'] = [
    ["name" => "name_full", "title" => "ФИО (полностью)", "type" => "text"],
    ["name" => "birthday", "title" => "Дата рождения", "type" => "date"],
    ["name" => "place_birthday", "title" => "Место рождения", "type" => "text"],
    ["name" => "phone", "title" => "Номер телефона", "type" => "text"],
    ["name" => "email", "title" => "E-mail", "type" => "email"],
    ["name" => "passport", "title" => "Паспорт", "type" => "text"],
    ["name" => "inn", "title" => "ИНН", "type" => "text"],
    ["name" => "snils", "title" => "Снилс", "type" => "text"],
    ["name" => "adress_reg", "title" => "Адрес Регистрации", "type" => "text"],
    ["name" => "adress_live", "title" => "Фактический адрес проживания", "type" => "text"],
    ["name" => "adress_work", "title" => "Место работы (адрес)", "type" => "text"],
    ["name" => "phone_work", "title" => "Место работы (телефон)", "type" => "text"],
    ["name" => "jobname_work", "title" => "Место работы (должность)", "type" => "text"],
    ["name" => "is_verified", "title" => "Пенсионер?", "type" => "radio"],
    ["name" => "is_verified", "title" => "Иная категория на обеспечении государства", "type" => "radio"],
    ["name" => "salary", "title" => "Размер дохода", "type" => "text"],
];


$this->includeComponentTemplate();
?>