function SetContact(value){
    if(value==0){
        var fields = document.querySelector("#sale_order_props");
        var inputs = fields.querySelectorAll("input");
        inputs.forEach(input=>{
            input.setAttribute("value","");
            title=input.getAttribute("data-input-title");
            if(title=="CITY") {
                input.setAttribute("data-city-id","");
            }
        });
    }else {
        const form_url = document.querySelector("[name='bx_url']");
        const new_url = atob(form_url.value) + "/ajax/getNewContact.php";
        BX.ajax({
            url: new_url,
            method: 'POST',
            data: {"ID": value},
            dataType: 'json',
            onsuccess: function (result) {
                var fields = document.querySelector("#sale_order_props");
                result.RESULT.PROFILE_FIELDS.forEach(prof=>{
                    const input = fields.querySelector(`[data-input-title="${prof.PROP_CODE}"]`);
                    input.setAttribute('value',prof.VALUE);
                    if (prof.PROP_CODE=="CITY"){
                        input.setAttribute('data-city-id',prof.CITY_CODE);
                    }
                });
            }
        });
    }
}


function checkZip(event){
    if(!isFinite(event.key) && !(event.key=="Backspace")){
        event.target.value = event.target.value.substring(0, event.target.value.length - 1);
    }
}


function setCity(value){
    const form_url = document.querySelector("[name='bx_url']");
    const new_url = atob(form_url.value) + "/ajax/updateCityZipLocation.php";

    if(value){
        BX.ajax({
            url: new_url,
            method: 'POST',
            data: {"ID": value, "type": "SET"},
            dataType: 'json',
            onsuccess: function (result) {
                //console.log(result);
                document.getElementById('bx-city-select').remove();

                document.querySelector(".bx-CITY-input-holder").value=result.RESULT.NAME_RU;

                document.querySelector(".bx-CITY-input-holder").setAttribute('data-city-id' , result.RESULT.CODE);
                document.querySelector(".bx-ZIP-input-holder").setAttribute("value", '')
                if (result.RESULT.ZIP_FORMATED){
					document.querySelector(".bx-ZIP-input-holder").setAttribute("maxlength", 7)
					document.querySelector(".bx-ZIP-input-holder").setAttribute("minlength", 7)
                    document.querySelector(".bx-ZIP-input-holder").setAttribute("value", result.RESULT.ZIP_FORMATED)
                }else{
                    document.querySelector(".bx-ZIP-input-holder").setAttribute("placeholder", "К сожалению в базе нет почтового индекса. Пожалуйста введите индекс вручную")
                    document.querySelector(".bx-ZIP-input-holder").setAttribute("maxlength", 6)
                    document.querySelector(".bx-ZIP-input-holder").setAttribute("minlength", 6)
                    document.querySelector(".bx-ZIP-input-holder").setAttribute('onkeyup','checkZip(event)');
                    document.querySelector(".bx-ZIP-input-holder").removeAttribute("disabled");
                }
            }
        });
    }
}

function getCity(value){
    const form_url = document.querySelector("[name='bx_url']");
    const new_url = atob(form_url.value) + "/ajax/updateCityZipLocation.php";
    if(value.length>2){
        BX.ajax({
            url: new_url,
            method: 'POST',
            data: {"city": value, "type": "GET"},
            dataType: 'json',
            onsuccess: function (result) {
                if(Object.keys(result.RESULT).length > 0){
                    if (document.getElementById('bx-city-select')){
                        var selectList = document.getElementById('bx-city-select');
                        selectList.innerHTML='';
                        selectList.setAttribute("size",Object.keys(result.RESULT).length<2?2:Object.keys(result.RESULT).length);
                        for (var key in result.RESULT) {
                            if (result.RESULT.hasOwnProperty(key)) {
                                var option = document.createElement("option");
                                option.setAttribute('value',result.RESULT[key].ID);
                                option.classList.add('sw-option');
                                option.innerText=result.RESULT[key].NAME_RU + " , " + result.RESULT[key].REGION_NAME + " , " + result.RESULT[key].COUNTRY_NAME;
                                selectList.append(option);
                            }
                        }
                    }else {
                        var selectList = document.createElement("select");
                        selectList.id='bx-city-select';
                        selectList.classList.add('jq-selectbox__dropdown','sw-select');
                        selectList.setAttribute("size",Object.keys(result.RESULT).length<2?2:Object.keys(result.RESULT).length);
                        selectList.setAttribute('onChange','setCity(this.value)')
                        for (var key in result.RESULT) {
                            if (result.RESULT.hasOwnProperty(key)) {
                                var option = document.createElement("option");
                                option.setAttribute('value',result.RESULT[key].ID);
                                option.classList.add('sw-option');
                                option.innerText=result.RESULT[key].NAME_RU  + " , " + result.RESULT[key].REGION_NAME + " , " + result.RESULT[key].COUNTRY_NAME;
                                selectList.append(option);
                            }
                        }
                        document.querySelector(".bx-CITY-input-holder").after(selectList);
                    }


                }
            }});
    }else{
        if(document.getElementById('bx-city-select')){
            var selectList = document.getElementById('bx-city-select');
            selectList.remove();
        }
    }

}

function backBasket(){
    document.querySelectorAll("[data-action-step]").forEach(item=>{
        if(item.getAttribute("data-action-step")=='2'){
            item.style.display='none';
        }
        if(item.getAttribute("data-action-step")=='1'){
            item.style.display='block';
        }
    });
}

function nextPayment(){
    var fields = document.querySelector("#sale_order_props");
    var inputs = fields.querySelectorAll("input");
    var errors = document.querySelectorAll(".error-title");
    let error_count=0;
    const array_inputs={};
    if(errors){
        errors.forEach(error=>{
            error.remove();
        })
    }

    inputs.forEach(input=>{
        if(input.value.length<=0){
            input_error_span = document.createElement("span");
            input_error_span.classList.add("error-title");
            input_error_span.setAttribute("style","color: red;")
            input_error_span.innerText="Это поле обязательно к заполнению";
            input.after(input_error_span)
            error_count++;
        }else {

            title = input.getAttribute("data-input-title");
            if(title=="CITY"){
                object={};
                object[input.getAttribute("data-props-id")]=input.getAttribute("data-city-id")
                array_inputs[title] = object
            }else if (title=="ZIP"){
                object={};
                object[input.getAttribute("data-props-id")]=input.value.replace(" ","")
				array_inputs[title] = object;
			}
			else{
                object={};
                object[input.getAttribute("data-props-id")]=input.value
                array_inputs[title]=object;
            }

        }
    })

    const jsn = JSON.stringify(array_inputs);
    // const jsn_text = btoa(jsn);
    const user = document.querySelector("[name='bx_profile_user']");
    user.setAttribute('value',jsn);
    if (error_count==0){
        document.querySelectorAll("[data-action-step]").forEach(item=>{
            if(item.getAttribute("data-action-step")=='2'){
                item.style.display='none';
            }
            if(item.getAttribute("data-action-step")=='3'){
                item.style.display='block';
                console.log(document.querySelector("#ID_PAY_SYSTEM_ID_14").checked);
                if(document.querySelector("#ID_PAY_SYSTEM_ID_14").checked){
                    popupToggle();
                }
            }
        });
    }
}