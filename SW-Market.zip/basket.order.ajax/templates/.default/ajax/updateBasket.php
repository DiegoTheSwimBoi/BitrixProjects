<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Sale\Basket;
Bitrix\Main\Loader::includeModule("sale");
Bitrix\Main\Loader::includeModule("catalog");

$arResult=[];
$arTotal=0;
$arCount=0;


$basket = Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());




$basketItem = $basket->getItemById($_POST['basketId']);
if ($basketItem)
{
    switch ($_POST['type']){
        case "up":{
            $quantity=(int)$basketItem->getField("QUANTITY")+1;
            $basketItem->setField("QUANTITY",$quantity);
            $basket->save();
            $arResult=["ID"=>$basketItem->getField("ID"),"QUANTITY"=>(int)$basketItem->getField("QUANTITY"),"PRICE"=>CurrencyFormat((int)$basketItem->getField("PRICE"), $basketItem->getField("CURRENCY")),"FULL_PRICE"=>CurrencyFormat((int)$basketItem->getField("PRICE")*(int)$basketItem->getField("QUANTITY"),$basketItem->getField("CURRENCY"))];
        }
        break;
        case "down":{
            if((int)$basketItem->getField("QUANTITY")>1){
                $quantity=(int)$basketItem->getField("QUANTITY")-1;
                $basketItem->setField("QUANTITY",$quantity);
                $basket->save();
                $arResult=["ID"=>$basketItem->getField("ID"),"QUANTITY"=>(int)$basketItem->getField("QUANTITY"),"PRICE"=>CurrencyFormat((int)$basketItem->getField("PRICE"), $basketItem->getField("CURRENCY")),"FULL_PRICE"=>CurrencyFormat((int)$basketItem->getField("PRICE")*(int)$basketItem->getField("QUANTITY"),$basketItem->getField("CURRENCY"))];
            }
        }
        break;
        case "delete":{
            $arResult=["ID"=>$basketItem->getField("ID"), "DELETE"=>true];
            $basketItem->delete();
            $basket->save();
        }
        break;
    }





}

$dbRes = \Bitrix\Sale\Basket::getList(
    [
        'select' => ['PRICE','QUANTITY'],
        'filter' => [
            '=FUSER_ID' => \Bitrix\Sale\Fuser::getId(),
            '=ORDER_ID' => null,
            '=LID' => \Bitrix\Main\Context::getCurrent()->getSite(),
            '=CAN_BUY' => 'Y',
        ]
    ]
);
$arCurrency= Bitrix\Currency\CurrencyManager::getBaseCurrency();
while ($item = $dbRes->fetch())
{
	$arCount++;
    $arTotal+=(int)$item["PRICE"]*(int)$item["QUANTITY"];
}

header("Content-type: application/json; charset=utf-8");
echo json_encode(['isSuccess' => true, 'RESULT' => $arResult, 'TOTAL_VALUES'=>['WEIGHT'=>$basket->getWeight(),"PRICE"=> $arTotal,"PRICE_FORMATED"=>CurrencyFormat($arTotal,$arCurrency),"COUNT"=>$arCount]]);