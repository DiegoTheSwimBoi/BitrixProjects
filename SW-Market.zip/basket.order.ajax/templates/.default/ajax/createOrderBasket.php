<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Sale\Basket;
use \Bitrix\Main,
\Bitrix\Main\Localization\Loc as Loc,
Bitrix\Main\Loader,
Bitrix\Main\Application,
Bitrix\Currency,
Bitrix\Sale\Delivery,
Bitrix\Sale\PaySystem,
Bitrix\Sale,
Bitrix\Sale\Order,
Bitrix\Sale\Affiliate,
Bitrix\Sale\DiscountCouponsManager,
Bitrix\Main\Context;
Bitrix\Main\Loader::includeModule("sale");
Bitrix\Main\Loader::includeModule("catalog");


function getPropertyByCode($propertyCollection, $code)  {
    foreach ($propertyCollection as $property)
    {
        if($property->getField('CODE') == $code)
            return $property;
    }
}


$orderId=0;


if(isset($_POST)){
	$basket = Bitrix\Sale\Basket::loadItemsForFUser(\Bitrix\Sale\Fuser::getId(), \Bitrix\Main\Context::getCurrent()->getSite());
	$currencyCode = Bitrix\Currency\CurrencyManager::getBaseCurrency();
	$order = \Bitrix\Sale\Order::create(\Bitrix\Main\Context::getCurrent()->getSite(), $_POST['user_id'],$currencyCode);
	$order->setField("PERSON_TYPE_ID",2);
	$order->setBasket($basket);

	$shipmentCollection = $order->getShipmentCollection();
$shipment = $shipmentCollection->createItem();
$service = Delivery\Services\Manager::getById(Delivery\Services\EmptyDeliveryService::getEmptyDeliveryServiceId());
$shipment->setFields(array(
    'DELIVERY_ID' => $service['ID'],
    'DELIVERY_NAME' => $service['NAME'],
));
//$shipmentItemCollection = $shipment->getShipmentItemCollection();
//$shipmentItem = $shipmentItemCollection->createItem($item);
//$shipmentItem->setQuantity($item->getQuantity());

$paymentCollection = $order->getPaymentCollection();
$payment = $paymentCollection->createItem();
$paySystemService = PaySystem\Manager::getObjectById($_POST['pay_system']);
$payment->setFields(array(
    'PAY_SYSTEM_ID' => $paySystemService->getField("PAY_SYSTEM_ID"),
    'PAY_SYSTEM_NAME' => $paySystemService->getField("NAME"),
    'SUM'=>htmlspecialchars($_POST['product_sum'])
));

$propertyCollection = $order->getPropertyCollection();

$name='';

foreach($_POST['user_info'] as $arKey=>$arInfo){

	$insertProperty = getPropertyByCode($propertyCollection,$arKey);

    if($arKey=="NAME"){
        foreach ($arInfo as $value){
            $name.=$value;
        }
    }

	if($arKey=="BIRTHDAY"){
        foreach ($arInfo as $value){
            $date = date("d.m.Y",strtotime(htmlspecialchars($value)));
            $insertProperty->setValue($date);
        }
	}else{
        foreach ($arInfo as $value) {
            $insertProperty->setValue(htmlspecialchars($value));
        }
	}

}

$line = 'Заказ с';

$line.=count($_POST['messages'])>1?" сайтов ":" сайта ";
foreach($_POST['messages'] as $arMessage){
    $line.=' '.$arMessage.",";
}


if(isset($_POST["installment"])){
    $line.=' В рассрочку: '.$_POST["installment"];
}

// CREATING NEW PROFILE;




if($_POST["save_profile"]=="true"){
    if ($_POST['profile_id']=='0' && !$ar = CSaleOrderUserProps::GetByID($_POST['profile_id'])) {

        $arFields = array("NAME" => $name, "USER_ID" => $_POST['user_id'], "PERSON_TYPE_ID" => 2);
        $aOrderProp = new CSaleOrderUserProps();
        $USER_PROPS_ID = $aOrderProp->Add($arFields);

        $arPropsFields = array();

        foreach ($_POST['user_info'] as $arKey => $arInfo) {
            $x = getPropertyByCode($propertyCollection, $arKey);
            foreach ($arInfo as $key => $value) {
                $aProp = ["USER_PROPS_ID" => $USER_PROPS_ID,"ORDER_PROPS_ID" => $key, "NAME"=>$x->getField("NAME"), "VALUE" => $value];
                $arPropsFields[] = $aProp;
            }
        }

        $arPropVal = new CSaleOrderUserPropsValue();

        foreach ($arPropsFields as $prop){
            $arPropVal->Add($prop);
        }

    }
}

$order->setField("PRICE",htmlspecialchars($_POST['product_sum']));
$order->setField('USER_DESCRIPTION', substr($line, 0, strlen($line) - 1));

$order->doFinalAction(true);
$result = $order->save();
$orderId = $order->getId();
}
header("Content-type: application/json; charset=utf-8");
echo json_encode(['isSuccess' => true, "RESULT"=>$orderId,"installment"=>isset($_POST["installment"])?true:false]);