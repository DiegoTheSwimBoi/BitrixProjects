<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Sale\Location;
use Bitrix\Sale\Basket;
Bitrix\Main\Loader::includeModule("sale");
Bitrix\Main\Loader::includeModule("catalog");

$db_propVals = CSaleOrderUserPropsValue::GetList(array("ID" => "ASC"), Array("USER_PROPS_ID"=>$_POST["ID"]));
$arResult=[];
while ($arPropVals = $db_propVals->Fetch())
{
    if ($arPropVals["PROP_CODE"]=="ZIP"){
        $zip=(int)$arPropVals["VALUE"];
        $zip_set=number_format($zip, 0, '', ' ');
        $arResult["PROFILE_FIELDS"][]=["PROP_CODE"=>"ZIP","VALUE"=>$zip_set, "PLACEHOLDER"=>"Индекс подставится автоматически после выбора города","DISABLED"=>true];
    }
    elseif ($arPropVals["PROP_CODE"]=="CITY"){
        $city_location=CSaleLocation::GetByID($arPropVals["VALUE"]);
        $arResult["PROFILE_FIELDS"][]=["PROP_CODE"=>"CITY","VALUE"=>$city_location["CITY_NAME"],"CITY_CODE"=>$city_location["CODE"]];
    }elseif ($arPropVals["PROP_CODE"]=="BIRTHDAY"){
        $arResult["PROFILE_FIELDS"][]=["PROP_CODE"=>$arPropVals["PROP_CODE"],"VALUE"=>date("Y-m-d",strtotime($arPropVals["VALUE"]))];
    } else{
        $arResult["PROFILE_FIELDS"][]=["PROP_CODE"=>$arPropVals["PROP_CODE"],"VALUE"=>$arPropVals["VALUE"]];
    }
}

header("Content-type: application/json; charset=utf-8");
echo json_encode(['isSuccess' => true, 'RESULT' => $arResult]);