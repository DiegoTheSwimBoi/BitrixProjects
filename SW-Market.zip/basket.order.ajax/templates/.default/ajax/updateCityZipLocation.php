<?php
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");

use Bitrix\Sale\Location;
use Bitrix\Sale\Basket;
Bitrix\Main\Loader::includeModule("sale");
Bitrix\Main\Loader::includeModule("catalog");

$arResult=[];

$type_search = htmlspecialcharsbx($_POST['type']);


switch ($type_search){
    case "GET":{
        $cityName = htmlspecialcharsbx($_POST['city']);

        $res = \Bitrix\Sale\Location\LocationTable::getList(array(
            'filter' => array('=NAME.LANGUAGE_ID' => LANGUAGE_ID, 'NAME.NAME' => $cityName.'%'),
            'select' => array('*',"NAME_RU"=>'NAME.NAME'),
            'limit' => 5,
        ));

        while($item = $res->fetch()) {
            $full_info=CSaleLocation::GetByID($item["ID"]);
            $item["REGION_NAME"]=$full_info["REGION_NAME"];
            $item["COUNTRY_NAME"]=$full_info["COUNTRY_NAME"];
            $item["CODE"]=$full_info["CODE"];
            $arResult[$item["ID"]]=$item;
        }
    }
    break;
    case "SET":{
        $arSelector=[];
        $cityID = htmlspecialcharsbx($_POST['ID']);
        $index="";

        $res = \Bitrix\Sale\Location\LocationTable::getList(array(
            'filter' => array('=NAME.LANGUAGE_ID' => LANGUAGE_ID, 'ID' => $cityID),
            'select' => array('*',"NAME_RU"=>'NAME.NAME'),
        ));

        while($item = $res->fetch()) {
            $arResult=$item;

            $arSelector = CSaleLocation::GetByID($cityID);

            $id=$arSelector["ID"];
			
			$location = new CSaleLocation();
			
			$res = $location->GetLocationZIP($id);
			
			if ($arLocation = $res->Fetch()) {
				$index = number_format((int)$arLocation["ZIP"], 0, '', ' ');
				$arResult["ZIP_FORMATED"] = $index;
				$arResult["ZIP"] = $arLocation["ZIP"];
			}else{
				$res_x = $location->GetLocationZIP($arSelector["REGION_ID"]);
				if ($arLoc = $res_x->Fetch()) {
				$index = number_format((int)$arLoc["ZIP"], 0, '', ' ');
				$arResult["ZIP_FORMATED"] = $index;
				$arResult["ZIP"] = $arLoc["ZIP"];
				}
			}
			

        }

    }
    break;
}




header("Content-type: application/json; charset=utf-8");
echo json_encode(['isSuccess' => true, 'RESULT' => $arResult]);
