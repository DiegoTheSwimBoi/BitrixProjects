function setQuantity(basketId, type) {


    const form = document.querySelector("[name='bx_min_sum_load']");
    const form_url = document.querySelector("[name='bx_url']");
    const value = atob(form.value);
    const object = JSON.parse(value);

    const min_price = object.BASKET_MIN_SUM;

    const new_url = atob(form_url.value) + "/ajax/updateBasket.php";

    postData = {
        'basketId': basketId,
        'type': type,
    };

    BX.ajax({
        url: new_url,
        method: 'POST',
        data: postData,
        dataType: 'json',
        onsuccess: function (result) {
            if (result.RESULT.DELETE) {
                document.querySelector(`[data-product-id="${result.RESULT.ID}"]`).remove();
            } else {
                document.querySelector(`[name="QUANTITY_INPUT_${result.RESULT.ID}"]`).value = result.RESULT.QUANTITY;
                document.querySelector(`#total_price_${result.RESULT.ID}`).innerHTML = result.RESULT.FULL_PRICE;
            }


            const button = document.querySelector("#_button_sum");


            if (min_price > result.TOTAL_VALUES.PRICE) {
                button.setAttribute("disabled", true);
                button.style.background = "#a8adb7";
                document.querySelector(".sum_message").style.display = "block";
                document.querySelector(".sum_message").innerHTML = "Минимальная сумма заказа от " + min_price + " ₽";
            } else {
                document.querySelector(".sum_message").style.display = "none";
                button.removeAttribute("disabled");
                button.removeAttribute("style");
            }

            /**
             if(min_price>result.TOTAL_VALUES.PRICE){
             if(!button.hasAttribute("disabled")){
             button.setAttribute("disabled");
             button.style.background="#a8adb7";
             document.querySelector(".sum_message").style="display: block;"
             }
             }else{
             if(button.hasAttribute("disabled")){
             button.removeAttribute("disabled");
             button.removeAttribute("style");
             document.querySelector(".sum_message").style="display: none;"
             }
             }
             */

            object.TOTAL_SUM = result.TOTAL_VALUES.PRICE;

            form.value = btoa(JSON.stringify(object));
            document.querySelector(".header-block-info-desc").innerHTML = result.TOTAL_VALUES.COUNT + " позиции на " + result.TOTAL_VALUES.PRICE_FORMATED;
            document.querySelector(".footer-amount-price").innerHTML = result.TOTAL_VALUES.PRICE_FORMATED;
            document.querySelector(".total-sum-price").innerHTML = result.TOTAL_VALUES.PRICE_FORMATED;
            document.querySelectorAll(".basket-checkout-block-total-description").forEach(item => {
                item.innerHTML = "Общий вес: " + result.TOTAL_VALUES.WEIGHT + " г.";
            });

        }
    });
}


function nextProfile(){

    const form = document.querySelector("[name='bx_min_sum_load']");
    const form_url = document.querySelector("[name='bx_url']");
    const value = atob(form.value);
    const object = JSON.parse(value);

        if(object.BASKET_MIN_SUM <= object.TOTAL_SUM) {
            if (object.USER_ID > 0) {
                document.querySelectorAll("[data-action-step]").forEach(item => {
                    if (item.getAttribute("data-action-step") == '1') {
                        item.style.display = 'none';
                    }
                    if (item.getAttribute("data-action-step") == '2') {
                        item.style.display = 'block';
                    }
                });
            } else {
                window.open(object.PATH_TO_AUTH, "_blank");
            }
        }
}

