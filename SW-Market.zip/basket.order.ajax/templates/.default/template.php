<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */

/** @var CBitrixBasketComponent $component */

use Bitrix\Main\Config\Option;
use Bitrix\Sale\DiscountCouponsManager;

\CModule::IncludeModule('bitlate.foodshop');
$showOldPrice = (Option::get('bitlate.foodshop', "NL_CATALOG_SHOW_OLD_PRICE", "N", SITE_ID) == "Y") ? true : false;
CModule::IncludeModule('bitlate.foodshop');
$curPage = $APPLICATION->GetCurPage() . '?' . $arParams["ACTION_VARIABLE"] . '=';
$arUrls = array(
    "delete" => $curPage . "delete&id=#ID#&load=Y",
    "delay" => $curPage . "delay&id=#ID#",
    "add" => $curPage . "add&id=#ID#",
);
unset($curPage);


$arBasketJSParams = array(
    'SALE_DELETE' => GetMessage("SALE_DELETE"),
    'SALE_DELAY' => GetMessage("SALE_DELAY"),
    'SALE_TYPE' => GetMessage("SALE_TYPE"),
    'TEMPLATE_FOLDER' => $templateFolder,
    'DELETE_URL' => $arUrls["delete"],
    'DELAY_URL' => $arUrls["delay"],
    'ADD_URL' => $arUrls["add"]
);
?>
<?

$offersParams = array();
$offersCartProps = COption::GetOptionString("bitlate.foodshop", 'NL_CATALOG_CART_OFFERS_PROPERTY_CODE', false, SITE_ID);
$offersCartProps = explode("|", $offersCartProps); ?>


<?php
//Код шаблона
//$APPLICATION->AddHeadScript($templateFolder."/script-load.js");
$APPLICATION->AddHeadScript($templateFolder . "/basket.js");
$APPLICATION->AddHeadScript($templateFolder . "/profile.js");
$APPLICATION->AddHeadScript($templateFolder . "/payment.js");
$stepIndex = 1;
$shop_has = [];
?>

<section class="cart" style="margin-top: 100px">
    <div class="inner-bg">
        <div class="advanced-container-medium">
            <article class="inner-container cart-container" id="open-x">


                <? if (!empty($arResult["ROWS"]["ITEMS"])): ?>

                    <form method="post" action="<?= POST_FORM_ACTION_URI ?>" name="basket_form" id="basket_form"
                          data-ajax="<?= $APPLICATION->GetCurPage() ?>?load=Y">
                        <div id="basket_items">
                            <div class="text-center">
                                <div class="cart-caption">Корзина / Оформление заказа</div>
                                <div class="cart-caption-desc product-price"><span
                                            data-count-title="<?= $arResult["COUNT"] ?>"
                                            data-price-title="<?= $arResult["TOTAL_PRICE_FORMATTED"] ?>"></span></div>
                                <div class="basket-checkout-block-total-description">Общий
                                    вес: <?= $arResult["TOTAL_WEIGHT"] ?> г.
                                </div>

                                <h3 style="color: red; margin-top: 2rem; <? $arResult["TOTAL_PRICE"] < $arParams["BASKET_MIN_SUM"] ? "display: none;" : "display: block;" ?>"
                                    class="sum_message"><?= $arResult["ERROR"]["MIN_SUM"] ?></h3>

                            </div>


                            <div style="background: #495057; color: white; font-size: larger; padding: 30px;"><span
                                        class="cart-content-counter show-for-large"><?= $stepIndex ?>. </span><span>Корзина</span>
                            </div>

                            <div data-action-step="<?= $stepIndex ?>">

                                <? if (!empty($arResult["ROWS"]["ITEMS"]["YARMARKA"])): ?>
                                    <div>
                                        <div style="background: #264f85; color: white; font-size: large; padding: 20px">
                                            <span>Ярмарка Столичная</span>
                                        </div>

                                        <? $shop_has["YARMARKA"] = "Ярмарка Столичная" ?>

                                        <? foreach ($arResult["ROWS"]["ITEMS"]["YARMARKA"] as $arItem): ?>

                                            <? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/include/card_item.php") ?>


                                        <? endforeach; ?>
                                    </div>
                                <? endif; ?>
                                <? if (!empty($arResult["ROWS"]["ITEMS"]["PAVILION"])): ?>
                                    <div>
                                        <div style="background: #222222; color: #FFC601; font-size: large; padding: 20px">
                                            <span>Павильон Крестьянский Продукт</span>
                                        </div>
                                        <? $shop_has["PAVILION"] = "Павильон Крестьянский Продукт" ?>
                                        <? foreach ($arResult["ROWS"]["ITEMS"]["PAVILION"] as $arItem): ?>

                                            <? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/include/card_item.php") ?>


                                        <? endforeach; ?>
                                    </div>
                                <? endif; ?>

                                <? if (!empty($arResult["ROWS"]["ITEMS"]["MARKET"])): ?>
                                    <div>
                                        <div style="background: #28ab5c; color: white; font-size: large; padding: 20px">
                                            <span>SW-Market</span>
                                        </div>
                                        <? $shop_has["MARKET"] = "SW-Market" ?>
                                        <? foreach ($arResult["ROWS"]["ITEMS"]["MARKET"] as $arItem): ?>

                                            <? include($_SERVER["DOCUMENT_ROOT"] . $templateFolder . "/include/card_item.php") ?>


                                        <? endforeach; ?>

                                    </div>
                                <? endif; ?>
                                <div class="cart-product-footer row large-up-2">
                                    <div class="column" id="coupons_block">
                                        <? $couponClass = '';
                                        $couponValue = '';
                                        if (!empty($arResult['COUPON_LIST'])) {
                                            foreach ($arResult['COUPON_LIST'] as $oneCoupon) {
                                                if ($oneCoupon['STATUS'] == DiscountCouponsManager::STATUS_APPLYED) {
                                                    $couponValue = htmlspecialcharsbx($oneCoupon['COUPON']);
                                                    $couponClass = 'good';
                                                    break;
                                                }
                                            }
                                        } ?>
                                        <div class="inline-block-container cart-product-footer-promo bx_ordercart_coupon <?= $couponClass ?>">
                                            <input type="text" id="coupon" name="COUPON" value="<?= $couponValue ?>"
                                                   data-coupon="<?= $couponValue ?>"
                                                   placeholder="<?= GetMessage('SALE_COUPON_PLACEHOLDER'); ?>"
                                                   class="inline-block-item">
                                            <button type="submit" class="button small secondary inline-block-item"
                                                    onclick="enterCoupon(); return false;"><?= GetMessage('SALE_COUPON_APPLY_BUTTON'); ?></button>
                                        </div>


                                        <input type="hidden"
                                               value="<?= base64_encode(json_encode(["BASKET_MIN_SUM" => (int)$arParams['BASKET_MIN_SUM'], "TOTAL_SUM" => $arResult["TOTAL_PRICE"], "USER_ID" => $USER->GetId(), "PATH_TO_AUTH" => $arParams["PATH_TO_AUTH"]])); ?>"
                                               name="bx_min_sum_load">

                                        <input type="hidden"
                                               value="<?= base64_encode(json_encode($shop_has)); ?>"
                                               name="bx_shops_load">
                                        <input type="hidden" value="<?= base64_encode($templateFolder) ?>"
                                               name="bx_url">
                                    </div>


                                    <div class="column cart-product-footer-amount price"><?= GetMessage("SALE_TOTAL") ?>
                                        <span
                                                class="footer-amount-price"><?= $arResult["TOTAL_PRICE_FORMATTED"] ?></span><br/>
                                        <p class="basket-checkout-block-total-description"><?= GetMessage("SALE_TOTAL_WEIGHT") ?> <?= $arResult["TOTAL_WEIGHT"] ?> <?= GetMessage("SALE_WEIGHT_G") ?>
                                            .</p>
                                        <?= GetMessage("SALE_TOTAL_NOTE") ?>
                                    </div>

                                    <div class="cart-footer">
                                        <a href="javascript:;"
                                           onclick="nextProfile();" <?= $arResult["TOTAL_PRICE"] < $arParams["BASKET_MIN_SUM"] ? "disabled" : "" ?>
                                           class="button"
                                           id="_button_sum"><?= GetMessage("SALE_ORDER") ?></a>
                                        <a href="#buy-to-click"
                                           class="button secondary go2buy"><?= GetMessage("SALE_ORDER_1_CLICK") ?></a>
                                        <input type="hidden" name="cart"
                                               value="<?= base64_encode(json_encode('Y')) ?>"/>
                                        <input type="hidden" name="props"
                                               value="<?= base64_encode(json_encode(array_unique($offersParams))) ?>"/>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <? $stepIndex++ ?>

                        </div>
                    </form>

                    <div style="background: #495057; color: white; font-size: larger; padding: 30px;"><span
                                class="cart-content-counter show-for-large"><?= $stepIndex ?>. </span><span>Контакты и доставка</span>
                    </div>
                    <div data-action-step="<?= $stepIndex ?>" style="display: none;">
                        <div class="cart-content">
                            <div class="text-center" style="padding: 30px; border: 2px solid #28ab5c;">
                                <span>Изменение способа доставки по соглосованию с менеджером в чате</span>
                            </div>
                            <div class="float-center large-7 xlarge-5 relative" style="margin-top: 50px;">
                                <div class="cart-content-counter show-for-large">1</div>
                                <label for="ID_PROFILE_ID">
                                    <strong>Выберите профиль доставки</strong>
                                    <div id="ID_PROFILE_ID-styler" class="jq-selectbox jqselect changed"
                                         style="display: inline-block; position: relative; z-index:20">
                                        <select name="PROFILE_ID" id="ID_PROFILE_ID" onchange="SetContact(this.value)"
                                                style="margin: 0px; padding: 0px; position: absolute; left: 0px; top: 0px; width: 100%; height: 100%; opacity: 0;"
                                                aria-invalid="false">
                                            <? foreach ($arResult["PROFILE"] as $arProfile): ?>
                                                <option value="<?= $arProfile["ID"] ?>"><?= $arProfile["NAME"] ?></option>
                                            <? endforeach; ?>
                                            <option value="0">Новый Профиль</option>
                                        </select>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div class="cart-content">
                            <div class="cart-content-counter show-for-large">2</div>
                            <fieldset class="input row" id="sale_order_props">
                                <? foreach ($arResult["FIELDS"] as $aKey => $arProfile): ?>
                                    <div class="columns" data-property-id-row="<?= $arProfile["ID"] ?>">
                                        <?

                                        $valueHTML = "";

                                        if ($arResult["PROFILE_FIELDS"][$aKey]["PROP_CODE"] == $arProfile["CODE"]) {
                                            $valueHTML .= $arResult["PROFILE_FIELDS"][$aKey]["VALUE"];
                                        } ?>
                                        <label for="ORDER_PROP_<?= $arProfile["ID"] ?>">
                                            <span style="font-size: large; color: #495057;"><?= $arProfile["NAME"] ?></span>
                                            <input type="<?= $arProfile["CODE"] == "BIRTHDAY" ? "date" : "text" ?>" <?= $arProfile["REQUIRED"] == "Y" ? "required" : "" ?>
                                                   style="padding: 0 2.8125rem 0 .9375rem; line-height: 2.8125rem;border-radius: .3125rem;color: #999;background: #eeeff1; box-shadow: none" <? if ($arProfile["CODE"] == "CITY"): ?> onkeyup="getCity(this.value)" data-city-id="<?= $arResult["PROFILE_FIELDS"][$aKey]["CITY_CODE"] ?>" <? endif; ?>
                                                   class="bx-<?= $arProfile["CODE"] ?>-input-holder"
                                                   value="<?= $arProfile["CODE"] == "BIRTHDAY" ? date("Y-m-d", strtotime($valueHTML)) : $valueHTML ?>"
                                                   name="ORDER_PROP_<?= $arProfile["ID"] ?>"
                                                   data-props-id="<?= $arProfile["ID"] ?>"
                                                   id="ORDER_PROP_<?= $arProfile["ID"] ?>"
                                                   placeholder="<?= $arResult["PROFILE_FIELDS"][$aKey]["PLACEHOLDER"] ?>" <?= $arResult["PROFILE_FIELDS"][$aKey]["DISABLED"] ? "disabled" : "" ?>
                                                   data-input-title="<?= $arProfile["CODE"] ?>" aria-required="true"
                                                   aria-invalid="false">
                                        </label>

                                    </div>
                                <? endforeach; ?>
                            </fieldset>
                        </div>
                        <div class="cart-product-footer row large-up-2">
                            <div class="cart-footer">
                                <fieldset class="radio large-7 xlarge-5">
                                    <input type="checkbox" id="SAVE_PROFILE" name="SAVE_PROFILE" class="show-for-sr"
                                           checked="checked">
                                    <label for="SAVE_PROFILE">Сохранить данные в профиль</label>
                                    <small>При повторном заказе, данные сами подставятся.</small><br>
                                    <small>В личном кабинете можете их обновить.</small>
                                </fieldset>
                                <a href="javascript:;" onclick="backBasket();" class="button secondary"
                                   id="_button_next">Назад</a>
                                <a href="javascript:;" onclick="nextPayment();" class="button" id="_button_next">Перейти
                                    к оплате</a>
                            </div>
                        </div>
                    </div>
                <? $stepIndex++ ?>

                <input type="hidden" name="bx_profile_user">


                    <div style="background: #222428; color: white; font-size: larger; padding: 30px;"><span
                                class="cart-content-counter show-for-large"><?= $stepIndex ?>. </span><span>Оплата</span>
                    </div>
                    <div data-action-step="<?= $stepIndex ?>" style="display: none;">
                        <div class="cart-content">
                            <div class="float-center large-4 xlarge-8 relative" style="margin-top: 25px;">

                                <strong>Выберите способ оплаты</strong>

                                <? foreach ($arResult["PAY_SYSTEM"] as $arPayMent): ?>

                                    <div style="margin-top: 15px;">
                                        <fieldset class="radio large-4 xlarge-8">
                                            <input type="radio" id="ID_PAY_SYSTEM_ID_<?= $arPayMent["ID"] ?>"
                                                   name="PAY_SYSTEM_ID" value="<?= $arPayMent["ID"] ?>"
                                                   class="show-for-sr" checked="checked">
                                            <label for="ID_PAY_SYSTEM_ID_<?= $arPayMent["ID"] ?>"
                                                   <? if ($arPayMent["NAME"] == "Рассрочка"): ?>onclick="popupToggle()" <? endif; ?> ><?= $arPayMent["NAME"] ?></label>
                                        </fieldset>
                                    </div>

                                <? endforeach; ?>


                            </div>
                        </div>
                        <div class="cart-product-footer row large-up-2">
                            <div class="cart-footer">
                                <a href="javascript:;" onclick="backPayment();" class="button secondary"
                                   id="_button_next">Назад</a>
                                <a href="javascript:;" onclick="checkOut();" class="button" id="_button_sum">Оформить
                                    заказ</a>
                            </div>
                        </div>
                    </div>


                    <div id="popup">
                        <h1 style="text-align: center;">Рассрочка</h1>
                        <div class="content">
                            <div class="overflowed-text">

                                <p>Рассрочка предоставляется компанией «SW-Market» без участия банков и иных кредитных
                                    организаций.</p>
                                <p>Рассрочка является беспроцентной, Вы выплачиваете лишь сумму стоимости заказа,
                                    поделённую на несколько частей (от двух до четырех, индивидуально).</p>
                                <p>Предоставление рассрочки возможно лишь по заказу стоимостью от 10 000 до 40 000
                                    рублей. При этом первоначальный взнос составляет 25% от суммы заказа, и оплачивается
                                    покупателем при заключении договора.
                                    Период рассрочки составляет от одного до двух месяцев и устанавливается Компанией по
                                    результату рассмотрения заявки.
                                    Рассрочка на оплату печатной продукции не предоставляется.
                                    Основные условия предоставления рассрочки:</p>

                                <p>1. Отсутствие у Заявителя задолженности перед Компанией;</p>
                                <p>2. Наличии истории заказав (от трёх и более);</p>
                                <p>3. Стоимость заказа от 10 000 до 40 000 рублей.</p>

                                <p>
                                    Для направления заявки заполните нижеприведенные графы и нажмите на кнопку
                                    «направить заявку».
                                    Ваша заявка будет рассмотрена Компанией. О результатах рассмотрения Вам будет
                                    сообщено посредствам смс сообщения и электронного письма, на указанные Вами
                                    контакты. Срок рассмотрения заявки составляет 24 часа.
                                    В случае одобрения, Вы также получите инструкцию о дальнейших шагах по оформлению
                                    рассрочки.
                                    Желаем Вам облегчения в заботе о друзьях и близких, находящихся в МЛС.
                                </p>
                                <p>
                                    В форме Анкеты учесть согласие обработку персональных данных.
                                </p>
                            </div>
                            <div class="inputBox">
                                <fieldset id="sale_order_props" style="width: 75%; margin-right: 0;" class="field-installment">
                                    <? foreach ($arResult["FORM_INPUTS"] as $index => $arPayMent): ?>
                                        <? if ($arPayMent["type"] != "radio"): ?>
                                            <label for="SYSTEM_ID_<?= $index ?>">
                                                <span style="font-size: large; color: #495057;"><?= $arPayMent["title"] ?></span>
                                                <input type="<?= $arPayMent["type"] ?>"
                                                       style="padding: 0 2.8125rem 0 .9375rem; line-height: 2.8125rem;border-radius: .3125rem;color: #999;background: #eeeff1; box-shadow: none"
                                                       name="<?= $arPayMent["name"] ?>" id="SYSTEM_ID_<?= $index ?>"
                                                       placeholder="<?= $arPayMent["title"] ?>">
                                            </label>
                                        <? else: ?>
                                            <div class="flex-row-line">
                                                <input type="radio" name="<?= $arPayMent["name"] ?>"
                                                       id="SYSTEM_ID_<?= $index ?>" value="<?=$arPayMent["title"]?>: да"
                                                       placeholder="<?= $arPayMent["title"] ?>"
                                                       style="width: 10%;">
                                                <label style="color: #495057;"
                                                       for="SYSTEM_ID_<?= $index ?>"><?= $arPayMent["title"] ?></label>
                                            </div>
                                        <br>
                                        <? endif; ?>
                                    <? endforeach; ?>
                                </fieldset>
                            </div>
                            <div style="margin-left: -30px; margin-top: 25px;">
                                <label for="ready-x"><input type="checkbox" id="ready-x">Согласие обработки персональных данных</label>
                                <a class="button" onclick="fieldInstallment();" id="_button_sum">Оформить рассрочку</a>
                            </div>

                        </div>
                        <a class="close" onclick="popupRemove();">✖</a>
                    </div>

                    <script>
                        function popupToggle() {
                            const popup = document.getElementById('popup');
                            popup.classList.add('active');
                        }

                        function popupRemove() {
                            const popup = document.getElementById('popup');
                            popup.classList.remove('active');
                        }
                    </script>


                <? else: ?>

                    <div id="empty_basket">
                        <div class="text-center">
                            <div class="cart-caption"><?= GetMessage("SALE_BASKET") ?></div>
                        </div>
                        <div class="cart-content cart-empty text-center inline-block-container">
                            <div class="cart-empty-icon inline-block-item vertical-middle">
                                <svg class="icon">
                                    <use xlink:href="#svg-icon-cart"></use>
                                </svg>
                            </div>
                            <br><br>
                            <div class="inline-block-item vertical-middle no-items"><?= GetMessage("SALE_NO_ITEMS") ?></div>
                        </div>
                    </div>
                <? endif; ?>

            </article>

            <article class="inner-container cart-container" id="close-x" style="display:none;">
                <div>
                    <div class="cart-content cart-empty text-center inline-block-container">
                        <div class="cart-empty-icon inline-block-item vertical-middle">
                            <svg class="icon">
                                <use xlink:href="#svg-icon-cart"></use>
                            </svg>
                        </div>
                        <br>
                        <div class="inline-block-item vertical-middle thanks-message">
                            Спасибо, что оформили заказ в нашем магазине.
                            <span id="order-post-info"></span><br><br><br>
                            <span id="order-post-pay"></span>
                        </div>
                    </div>
                </div>
            </article>

        </div>
    </div>
</section>