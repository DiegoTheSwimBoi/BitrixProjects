<div class="callout cart-product-item inline-block-container"
     data-product-id="<?= $arItem["ID"] ?>" id="<?= $arItem["ID"] ?>">
    <div class="inline-block-item vertical-middle cart-product-item-preview">
        <img src="<?= $arItem["PICTURE"] ?>" alt="">
    </div>
    <div class="inline-block-item vertical-middle cart-product-item-info">
        <div class="inline-block-container">
            <div class="inline-block-item vertical-middle cart-product-item-desc">
                <? if (strlen($arItem["DETAIL_PAGE_URL"]) > 0): ?><a
                    href="<?= $arItem["DETAIL_PAGE_URL"] ?>"
                    class="cart-product-item-name"><? endif; ?>
                    <?= $arItem["NAME"] ?>
                    <? if (strlen($arItem["DETAIL_PAGE_URL"]) > 0): ?></a><? endif; ?>


                <a href="#" class="button transparent add2liked"
                   data-ajax="<?= SITE_DIR ?>nl_ajax/favorite.php"
                   data-product-id="<?= $arItem['PRODUCT_ID'] ?>">
                    <svg class="icon">
                        <use xlink:href="#svg-icon-liked"></use>
                    </svg>
                    <span><?= GetMessage("SALE_FAVORITE") ?></span>
                </a>
            </div>
            <div class="inline-block-item vertical-middle cart-product-item-price medium-up-2 large-up-3">
                <div class="column">
                    <div class="product-count">
                        <div class="product-info-caption"><?= GetMessage("SALE_QUANTITY") ?></div>
                        <div class="input-group">
                            <div class="input-group-button">
                                <!--                                                                onclick="setQuantity(-->
                                <?php //= $arItem["ID"] ?><!--, -->
                                <?php //= $arItem["MEASURE_RATIO"] ?><!--, 'down', -->
                                <?php //= $useFloatQuantityJS ?><!--);"-->
                                <button class="button decrement" type="button"
                                        onclick="setQuantity(<?= $arItem["ID"] ?>, 'down');">
                                    -
                                </button>
                            </div>
                            <input class="input-group-field" type="number"
                                   name="QUANTITY_INPUT_<?= $arItem["ID"] ?>"
                                   min="1"
                                   value="<?= $arItem["QUANTITY"] ?>"
                                   id="QUANTITY_INPUT_<?= $arItem["ID"] ?>">
                            <div class="input-group-button">
                                <button class="button increment" type="button"
                                        onclick="setQuantity(<?= $arItem["ID"] ?>,  'up');">
                                    +
                                </button>
                            </div>
                        </div>
                        <input type="hidden" id="QUANTITY_<?= $arItem['ID'] ?>"
                               name="QUANTITY_<?= $arItem['ID'] ?>"
                               value="<?= $arItem["QUANTITY"] ?>"/>
                    </div>
                </div>
                <div class="column float-right">
                    <div class="product-price">
                        <div class="product-info-caption"><?= GetMessage("SALE_TOTAL") ?></div>
                        <div class="main"
                             id="total_price_<?= $arItem["ID"] ?>"><?= CCurrencyLang::CurrencyFormat($arItem["PRICE"] * $arItem["QUANTITY"], $arItem["CURRENCY"]) ?></div>
                    </div>
                </div>
                <div class="column show-for-large">
                    <div class="product-price">
                        <div class="product-info-caption"><?= GetMessage("SALE_PRICE_1") ?> <?= str_replace(GetMessage("SALE_MEASURE_SEARCH"), GetMessage("SALE_MEASURE_REPLACE"), $arItem["MEASURE_TEXT"]) ?></div>
                        <div class="main"
                             id="current_price_<?= $arItem["ID"] ?>"><?= CCurrencyLang::CurrencyFormat($arItem["PRICE"] * 1, $arItem["CURRENCY"]) ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button class="close-button" type="button"
            onclick="setQuantity(<?= $arItem["ID"] ?>,  'delete');">
        <span aria-hidden="true">+</span>
    </button>
</div>