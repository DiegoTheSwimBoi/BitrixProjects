document.addEventListener("DOMContentLoaded", function(event) {
    // const form=document.querySelector("[name='bx_min_sum_load']");
    // const value = atob(form.value);
    // console.log(JSON.parse(value));


    const item_title =document.querySelector("[data-count-title]");
    if (item_title){
        const count = item_title.getAttribute("data-count-title");
        const price = item_title.getAttribute("data-price-title");
        let line="";
        if(count<2){
            line+="товар";
        }else if(count>2 && count<5){
            line+="товара";
        }else{
            line+="товаров";
        }
        item_title.innerHTML=`${count} ${line} на <span class="total-sum-price">${price}</span>`;

        const button =document.querySelector("#_button_sum");

        if(button.hasAttribute("disabled")){
            button.style.background="#a8adb7";
        }
    }

});
