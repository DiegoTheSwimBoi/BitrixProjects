function backPayment(){
    document.querySelectorAll("[data-action-step]").forEach(item=>{
        if(item.getAttribute("data-action-step")=='3'){
            item.style.display='none';
        }
        if(item.getAttribute("data-action-step")=='2'){
            item.style.display='block';
        }
    });
}

function checkOut(installment=null) {
    if(document.querySelector("#ID_PAY_SYSTEM_ID_14")!=undefined){
        if(document.querySelector("#ID_PAY_SYSTEM_ID_14").checked && installment==null){
            popupToggle();
            return;
        }
    }

    //bx_shops_load
    const user = document.querySelector("[name='bx_profile_user']");
    const form = document.querySelector("[name='bx_min_sum_load']");
    const messages_ = document.querySelector("[name='bx_shops_load']");
    const form_url = document.querySelector("[name='bx_url']");
    const profile_ = document.querySelector("[name='PROFILE_ID']");
    const save_profile = document.querySelector("[name='SAVE_PROFILE']");
    const value = atob(form.value);
    const message = atob(messages_.value);
    const message_object = JSON.parse(message);
    const object = JSON.parse(value);
    const user_info = JSON.parse(user.value);
    const pay_systems = document.querySelectorAll("[name='PAY_SYSTEM_ID']");
    let pay_id=11;

    pay_systems.forEach(pay=>{
        if(pay.checked){
            pay_id=pay.value;
        }
    });


    const new_url = atob(form_url.value) + "/ajax/createOrderBasket.php";
    if(object.USER_ID>0){
        if (object.TOTAL_SUM >= object.BASKET_MIN_SUM) {
			orderData = {
                'user_info': user_info,
                'product_sum': object.TOTAL_SUM,
                'user_id': object.USER_ID,
                'pay_system': pay_id,
                'messages': message_object,
                'profile_id': profile_.value,
                'save_profile': save_profile.checked,
                'installment': installment
            };


			BX.ajax({
                url: new_url,
                method: 'POST',
                data: orderData,
                dataType: 'json',
                onsuccess: function (result) {
                    document.querySelector("#open-x").style.display="none";
                    let block = document.querySelector("#close-x");
                    if(result.installment){
                        block.querySelector("#order-post-info").innerHTML="<b>Номер заказа № "+result.RESULT + `</b>. О результатах рассмотрения заявки на рассрочку Менеджер сообщит по электронной почте или по номеру телефона, указанные Вами в заявке.`;
                        block.style.display="block";
                        block.querySelector("#order-post-pay").innerHTML=`Ознакомится с шаблоном Договора о рассрочке оплаты <b>Вы можете по ссылке</b> <br><br> <a href='/upload/installment.docx' onclick="redirect()" download class="button">Ознакомиться</a><br><br><a href='/'  class="button">На главную</a>`;
                    }else{
                        block.querySelector("#order-post-info").innerHTML="Номер заказа № "+result.RESULT + `  - Заказ можете посмотреть <a href='${object.PATH_TO_AUTH}'> в личном кабинете</a>`;
                        block.style.display="block";
                        block.querySelector("#order-post-pay").innerHTML=`Заказ можете <b>оплатить</b> по ссылке <a href='/personal/order/payment/?ORDER_ID=${result.RESULT}' class="button">Оплатить</a>`;
                    }

                }
            });
        }
    }else {
        window.open(object.PATH_TO_AUTH, "_blank");
    }
}




function fieldInstallment(){
    const array_field = document.querySelectorAll(".field-installment input");
    if(document.querySelector("#ready-x").checked){
        let line ="";
        for (let i = 0; i<array_field.length; i++){
            if(array_field[i].getAttribute("type")=="radio"){
                if (array_field[i].checked){
                    line+=`${array_field[i].value};  `
                }
            }else {
                line+=`${array_field[i].value};  `
            }
        }
        popupRemove();
        checkOut(line);
    }
}

