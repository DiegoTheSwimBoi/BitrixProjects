<?
$MESS["NAME"] = "Оформление заказа в корзине";
$MESS["DESCRIPTION"] = "Позволяет оформлять заказ в корзине";
$MESS["PATH_ID"] = "main";
$MESS["PATH_NAME"] = "Custom";
?>