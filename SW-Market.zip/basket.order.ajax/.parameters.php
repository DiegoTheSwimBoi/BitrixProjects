<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if(!CModule::IncludeModule("iblock"))
    return;

use Bitrix\Main\Loader,
	Bitrix\Catalog,
	Bitrix\Iblock;

if (!Loader::includeModule('sale'))
	return;

//$arTypesEx = CIBlockParameters::GetIBlockTypes(array("-"=>" "));
//
//$arIBlocks=array();
//$db_iblock = CIBlock::GetList(array("SORT"=>"ASC"), array("TYPE" => ($arCurrentValues["IBLOCK_TYPE"]!="-"?$arCurrentValues["IBLOCK_TYPE"]:"")));
//while($arRes = $db_iblock->Fetch())
//    $arIBlocks[$arRes["ID"]] = "[".$arRes["ID"]."] ".$arRes["NAME"];
//
//$arProperty_LNS = array();
//$rsProp = CIBlockProperty::GetList(array("sort"=>"asc", "name"=>"asc"), array("ACTIVE"=>"Y", "IBLOCK_ID"=>($arCurrentValues["IBLOCK_ID"])));
//
//while ($arr=$rsProp->Fetch())
//{
//    $arProperty[$arr["CODE"]] = "[".$arr["CODE"]."] ".$arr["NAME"];
//    if (in_array($arr["PROPERTY_TYPE"], array("L", "N", "S")))
//    {
//        $arProperty_LNS[$arr["CODE"]] = "[".$arr["CODE"]."] ".$arr["NAME"];
//    }
//}

$arPayArray=[];

$paySystemResult = \Bitrix\Sale\PaySystem\Manager::getList(array(
	'order'=> Array("SORT"=>"DESC"),
	'filter'  => array(
		'ACTIVE' => 'Y',
	),
	'select'=> array(
		'ID','NAME'
	),
));

while ($paySystem = $paySystemResult->fetch()) {
	$arPayArray[$paySystem['ID']]=$paySystem['NAME'];
}

$arColumns = array(
	"PREVIEW_PICTURE" => GetMessage("SBB_PREVIEW_PICTURE"),
	"DETAIL_PICTURE" => GetMessage("SBB_DETAIL_PICTURE"),
	"PREVIEW_TEXT" => GetMessage("SBB_PREVIEW_TEXT"),
	"DISCOUNT" => GetMessage("SBB_BDISCOUNT"),
	"WEIGHT" => GetMessage("SBB_BWEIGHT"),
	"PROPS" => GetMessage("SBB_BPROPS"),
	"DELETE" => GetMessage("SBB_BDELETE"),
	"DELAY" => GetMessage("SBB_BDELAY"),
	"TYPE" => GetMessage("SBB_BTYPE"),
	"SUM" => GetMessage("SBB_BSUM")
);

$iblockIds = array();
$iblockNames = array();

if (Loader::includeModule('catalog'))
{
	$parameters = array(
		'select' => array('IBLOCK_ID', 'NAME' => 'IBLOCK.NAME'),
		'order' => array('IBLOCK_ID' => 'ASC'),
	);

	$siteId = isset($_REQUEST['src_site']) && is_string($_REQUEST['src_site']) ? $_REQUEST['src_site'] : '';
	$siteId = mb_substr(preg_replace('/[^a-z0-9_]/i', '', $siteId), 0, 2);
	if (!empty($siteId) && is_string($siteId))
	{
		$parameters['select']['SITE_ID'] = 'IBLOCK_SITE.SITE_ID';
		$parameters['filter'] = array('SITE_ID' => $siteId);
		$parameters['runtime'] = array(
			'IBLOCK_SITE' => array(
				'data_type' => 'Bitrix\Iblock\IblockSiteTable',
				'reference' => array(
					'ref.IBLOCK_ID' => 'this.IBLOCK_ID',
				),
				'join_type' => 'inner'
			)
		);
	}

	$catalogIterator = Catalog\CatalogIblockTable::getList($parameters);
	while ($catalog = $catalogIterator->fetch())
	{
		$catalog['IBLOCK_ID'] = (int)$catalog['IBLOCK_ID'];
		$iblockIds[] = $catalog['IBLOCK_ID'];
		$iblockNames[$catalog['IBLOCK_ID']] = $catalog['NAME'];
	}
	unset($catalog, $catalogIterator);

	$listProperties = array();

	if (!empty($iblockIds))
	{
		$arProps = array();
		$propertyIterator = Iblock\PropertyTable::getList(array(
			'select' => array('ID', 'CODE', 'NAME', 'IBLOCK_ID', 'PROPERTY_TYPE'),
			'filter' => array('@IBLOCK_ID' => $iblockIds, '=ACTIVE' => 'Y', '!=XML_ID' => CIBlockPropertyTools::XML_SKU_LINK),
			'order' => array('IBLOCK_ID' => 'ASC', 'SORT' => 'ASC', 'ID' => 'ASC')
		));
		while ($property = $propertyIterator->fetch())
		{
			$property['ID'] = (int)$property['ID'];
			$property['IBLOCK_ID'] = (int)$property['IBLOCK_ID'];
			$property['CODE'] = (string)$property['CODE'];

			if ($property['CODE'] == '')
			{
				$property['CODE'] = $property['ID'];
			}

			if ($property['PROPERTY_TYPE'] === 'L')
			{
				$listProperties[$property['CODE']] = $property['NAME'].' ['.$property['CODE'].']';
			}

			if (!isset($arProps[$property['CODE']]))
			{
				$arProps[$property['CODE']] = array(
					'CODE' => $property['CODE'],
					'TITLE' => $property['NAME'].' ['.$property['CODE'].']',
					'ID' => array($property['ID']),
					'IBLOCK_ID' => array($property['IBLOCK_ID'] => $property['IBLOCK_ID']),
					'IBLOCK_TITLE' => array($property['IBLOCK_ID'] => $iblockNames[$property['IBLOCK_ID']]),
					'COUNT' => 1
				);
			}
			else
			{
				$arProps[$property['CODE']]['ID'][] = $property['ID'];
				$arProps[$property['CODE']]['IBLOCK_ID'][$property['IBLOCK_ID']] = $property['IBLOCK_ID'];
				if ($arProps[$property['CODE']]['COUNT'] < 2)
					$arProps[$property['CODE']]['IBLOCK_TITLE'][$property['IBLOCK_ID']] = $iblockNames[$property['IBLOCK_ID']];
				$arProps[$property['CODE']]['COUNT']++;
			}
		}
		unset($property, $propertyIterator);

		$propList = array();
		foreach ($arProps as &$property)
		{
			$iblockList = '';
			if ($property['COUNT'] > 1)
			{
				$iblockList = ($property['COUNT'] > 2 ? ' ( ... )' : ' ('.implode(', ', $property['IBLOCK_TITLE']).')');
			}
			$propList['PROPERTY_'.$property['CODE']] = $property['TITLE'].$iblockList;
		}
		unset($property, $arProps);

		if (!empty($propList))
			$arColumns = array_merge($arColumns, $propList);
		unset($propList);
	}
}




$arComponentParameters = array(
    "PARAMETERS" => array(
		"BASKET_MIN_SUM"=>array(
        "PARENT" => "BASE",
			"NAME"=>GetMessage("BASKET_MIN_SUM"),
			"TYPE" => "STRING",
			"SORT"=>1,
            "DEFAULT"=>1000
		),
		"PATH_TO_AUTH"=>array(
			"PARENT" => "BASE",
			"NAME"=>GetMessage("PATH_TO_AUTH"),
			"TYPE" => "STRING",
			"SORT"=>2,
			"DEFAULT"=>"/personal/"
		),
        "PRODUCT_SECTION_TYPE"=> array(
            "PARENT"=>"BASE",
            "NAME"=>GetMessage("PRODUCT_SECTION_TYPE"),
            "TYPE"=>"LIST",
            "VALUES"=>["DEFAULT"=>GetMessage("PRODUCT_SECTION_TYPE_DEFAULT"),"YARMARKA"=>GetMessage("PRODUCT_SECTION_TYPE_YARMARKA"),"PAVILION"=>GetMessage("PRODUCT_SECTION_TYPE_PAVILION")],
            "MULTIPLE" => "Y",
			"DEFAULT"=>array("DEFAULT"),
            "SIZE"=>3,
            "SORT"=>3,
        ),
        "HIDE_COUPON" => Array(
			"NAME" => GetMessage("BASKET_HIDE_COUPON"),
			"TYPE" => "CHECKBOX",
			"VALUES" => array(
				"N" => GetMessage("BASKET_DESC_NO"),
				"Y" => GetMessage("BASKET_DESC_YES")
			),
			"DEFAULT" => "N",
			"PARENT" => "ADDITIONAL_SETTINGS",
		),
		"PAYMENT_SECTION"=> array(
			"NAME"=>GetMessage("PAYMENT_SECTION"),
			"TYPE"=>"LIST",
			"VALUES"=>$arPayArray,
			"MULTIPLE" => "Y",
			"DEFAULT"=>array(10,11),
			"SIZE"=>count($arPayArray),
			"PARENT" => "ADDITIONAL_SETTINGS",
		),
		"COLUMNS_LIST_EXT" => Array(
			"NAME" => GetMessage("SBB_COLUMNS_LIST"),
			"TYPE" => "LIST",
			"MULTIPLE" => "Y",
			"VALUES" => $arColumns,
			"DEFAULT" => array('PREVIEW_PICTURE', 'DISCOUNT', 'DELETE', 'DELAY', 'TYPE', 'SUM'),
			"COLS" => 25,
			"SIZE" => 7,
			"ADDITIONAL_VALUES" => "N",
			"PARENT" => "VISUAL",
			'REFRESH' => isset($templateProperties['COLUMNS_LIST_MOBILE']) ? 'Y' : 'N',
		),
    ),
);
?>
