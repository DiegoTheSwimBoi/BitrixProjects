<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<?php $arComponentDescription = array(
    "NAME" => GetMessage("NAME"),
    "DESCRIPTION" => GetMessage("DESCRIPTION"),
    "ICON" => "/images/icon.gif",
    "SORT" => 500,
    "CACHE_PATH" => "Y",
    "PATH" => array(
        "ID" => GetMessage("PATH_ID"),
        "NAME" => GetMessage("PATH_NAME")
    ),
);
?>