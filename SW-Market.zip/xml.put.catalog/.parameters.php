<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if(!CModule::IncludeModule("iblock"))
    return;

$arTypesEx = CIBlockParameters::GetIBlockTypes(array("-"=>" "));

$arIBlocks=array();
$db_iblock = CIBlock::GetList(array("SORT"=>"ASC"), array("TYPE" => ($arCurrentValues["IBLOCK_TYPE"]!="-"?$arCurrentValues["IBLOCK_TYPE"]:"")));
while($arRes = $db_iblock->Fetch())
    $arIBlocks[$arRes["ID"]] = "[".$arRes["ID"]."] ".$arRes["NAME"];

$arProperty_LNS = array();
$rsProp = CIBlockProperty::GetList(array("sort"=>"asc", "name"=>"asc"), array("ACTIVE"=>"Y", "IBLOCK_ID"=>($arCurrentValues["IBLOCK_ID"])));

while ($arr=$rsProp->Fetch())
{
    $arProperty[$arr["CODE"]] = "[".$arr["CODE"]."] ".$arr["NAME"];
    if (in_array($arr["PROPERTY_TYPE"], array("L", "N", "S")))
    {
        $arProperty_LNS[$arr["CODE"]] = "[".$arr["CODE"]."] ".$arr["NAME"];
    }
}

$arComponentParameters = array(
    "PARAMETERS" => array(
		"ELEMENTS_LINK"=> array(
			"PARENT" => "BASE",
			"NAME"=>GetMessage("ELEMENTS_LINK_NAME"),
			"TYPE" => "STRING",
			"SORT"=>1,
		),
		"ELEMENTS_FILE"=> array(
			"PARENT"=>"BASE",
			"NAME"=>GetMessage("ELEMENTS_FILE_NAME"),
			"TYPE"=>"FILE",
			"FD_TARGET" => "F",
			"FD_EXT" => 'json,xml',
			"SORT"=>2,
		),
		"ELEMENTS_TYPE"=> array(
			"PARENT"=>"BASE",
			"NAME"=>GetMessage("ELEMENTS_TYPE_NAME"),
			"TYPE"=>"LIST",
			"VALUES"=>["news"=>GetMessage("ELEMENTS_TYPE_NEWS_NAME"),"hits"=>GetMessage("ELEMENTS_TYPE_HITS_NAME")],
			"SORT"=>3,
		)
    ),
);
?>
