<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
?>


    <?php if (!empty($arResult)): ?>
        <div class="container row tabs-content" data-tabs-content="main-product-tabs">
            <div class="tabs-panel is-active" id="product-tab-<?=$arParams["ELEMENTS_TYPE"]?>" role="tabpanel" aria-hidden="false"
                 aria-labelledby="product-tab-<?=$arParams["ELEMENTS_TYPE"]?>-label">
                <div class="products-flex-grid product-grid product-grid-<?=$arParams["ELEMENTS_TYPE"]?>"
                     style="position: relative; height: 2900px;">
                    <div class="products-flex-grid product-grid" style="position: relative; height: 2900px;">
                        <?php foreach ($arResult as $arItem): ?>
                            <div class="products-flex-item" id="bx_3966226736_107864">
                                <div class="item column text-center hover-elements">
                                    <div class="img-wrap">
                                        <a href="<?= $arItem["DETAIL_PAGE_URL"] ?>" target="_blank">
                                        <img id="bx_3966226736_107864_pict" src="<?= $arItem["DETAIL_PICTURE"] ?>"
                                             data-src="<?= $arItem["DETAIL_PICTURE"] ?>" class="thumbnail lazy"
                                             alt="<?= $arItem["NAME"] ?>">
                                        </a>
                                    </div>
                                    <div class="name">
                                        <a href="<?= $arItem["DETAIL_PAGE_URL"] ?>" target="_blank"
                                           class="name"><span><?= $arItem["NAME"] ?></span></a>
                                    </div>
                                    <div id="bx_3966226736_107864_price_block">
                                        <div class="price"
                                             id="bx_3966226736_107864_price"><?= $arItem["PRICE_FORMATED"] ?></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>






