<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();


$arFields = [];
$arResult = [];

if ($arParams["ELEMENTS_LINK"] != "") {
    $link = htmlspecialcharsEx($arParams["ELEMENTS_LINK"]);
    $getFileMimeTypeFromURL = explode(".", $link);
    if (!empty($getFileMimeTypeFromURL)) {
        if ($getFileMimeTypeFromURL[count($getFileMimeTypeFromURL) - 1] == "json") {
            FileJSONCatalog::initImport($link);
            $arFields = FileJSONCatalog::getElements(true);
        } elseif ($getFileMimeTypeFromURL[count($getFileMimeTypeFromURL) - 1] == "xml") {
            FileJSONCatalog::initImport($link);
            $arFields = FileJSONCatalog::getXMLElements();
        }
    }
} else if ($arParams["ELEMENTS_FILE"] != "") {
    $link = htmlspecialcharsEx($arParams["ELEMENTS_FILE"]);
    $getFileMimeTypeFromURL = explode(".", $link);
    if (!empty($getFileMimeTypeFromURL)) {
        if ($getFileMimeTypeFromURL[count($getFileMimeTypeFromURL) - 1] == "json") {
            FileJSONCatalog::initImport($link);
            $arFields = FileJSONCatalog::getElements();
        } elseif ($getFileMimeTypeFromURL[count($getFileMimeTypeFromURL) - 1] == "xml") {
            FileJSONCatalog::initImport($link);
            $arFields = FileJSONCatalog::getXMLElements();
        }
    }
}


if (!empty($arFields)) {
    foreach ($arFields as $arFieldValue) {
        $arResult[] = [
            "NAME" => (string)$arFieldValue->name?:(string)$arFieldValue->model?:"",
            "DETAIL_PAGE_URL" => (string)$arFieldValue->url,
            "PRICE" => (string)$arFieldValue->price,
            "PRICE_FORMATED" => (string)$arFieldValue->price . " ₽",
            "DETAIL_PICTURE" => (string)$arFieldValue->picture
        ];
    }
}

$this->includeComponentTemplate();
?>
