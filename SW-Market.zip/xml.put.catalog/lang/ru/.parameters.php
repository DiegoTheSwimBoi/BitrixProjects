<?
$MESS["ELEMENTS_LINK_NAME"] = "Ссылка на прайс-лист";
$MESS["ELEMENTS_FILE_NAME"] = "Файл";
$MESS["ELEMENTS_TYPE_NAME"] = "Тип";
$MESS["ELEMENTS_TYPE_NEWS_NAME"] = "Ярмарка";
$MESS["ELEMENTS_TYPE_HITS_NAME"] = "Павильон";
?>