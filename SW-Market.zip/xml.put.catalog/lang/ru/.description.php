<?
$MESS["NAME"] = "Парсер xml файла в каталог";
$MESS["DESCRIPTION"] = "Позволяет выводить данные из xml/json/url на сайт";
$MESS["PATH_ID"] = "main";
$MESS["PATH_NAME"] = "Custom";
?>