<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Способы доставки заказов");
?><p>
 <b style="color: var(--basic_text_black); font-family: var(--ui-font-family-primary, var(--ui-font-family-helvetica));">Города, в которые &nbsp;мы уже отправили ваши заказы:</b>
</p>
 <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A4a682bdd7d6789964cf3a47132c94b0712e12eea0b3f8e7c87abc0f45b1d64c7&amp;source=constructor" width="1056" height="563" frameborder="0"></iframe><br>
 <br>
 Наш интернет-магазин предлагает несколько вариантов доставки:
<ul>
	<li>курьерская;</li>
	<li>самовывоз из магазина;</li>
	<li>доставка попутным грузом с заявкой через сайт:&nbsp;<a href="https://ati.su/">https://ati.su/</a></li>
	<li>транспортной компанией.</li>
</ul>
<h3>Курьерская доставка*</h3>
<p>
	 Вы можете заказать доставку товара с помощью курьера, который прибудет по указанному адресу в согласованное с Вами время. Курьерская служба, после поступления товара на склад, свяжется с вами и предложит выбрать удобное время доставки. Уточнит адрес.
</p>
<p>
	 По прибытию заказа, Вы выгружаете его, осматривая на предмет целостности. В случае замечаний, связываетесь с нами для решения возникших вопросов.
</p>
<p>
 <br>
</p>
<p>
</p>
<blockquote>
	<p>
		 *Действует ли в вашем городе курьерская служба, уточняйте у менеджера магазина.
	</p>
</blockquote>
<h3>Самовывоз со склада-производства</h3>
<p>
	 Вы можете забрать товар в одном из наших складов. Список складов, которые выдают заказы от нашей компании появится у вас в корзине. Когда заказ поступит в ваш город, вам придёт уведомление. Вы просто идёте в этот склад, обращаетесь к сотруднику&nbsp;и называете номер заказа. Забрать заказ может ваш друг или родственник, который знает номер и имя, на кого он оформлен.
</p>
<h3>Доставка ТК или попутным грузом</h3>
<p>
</p>
<p>
	 Доставка транспортными компаниями или попутным грузом через сайт&nbsp;<a href="https://ati.su/">https://ati.su/</a>&nbsp;согласовывается отдельно с менеджером магазина.
</p>
<p>
	 Через сайт АТИ.SU:&nbsp;заявка на доставку выставляется на бирже перевозок, и по оптимальной цене подбирается автоперевозчик. Стоимость доставки и вариант оплаты согласовывается с заказчиком.
</p>
<p>
</p>
<p>
	 Через ТК:&nbsp;доставка осуществляется по тарифам выбранной компаний. Доставку до терминала производим за свой счет.
</p>
<p>
	 О доставке в другие регионы России и страны СНГ уточняйте у менеджеров магазина
</p>
    <style>
        /**{*/
        /*    margin: 0;*/
        /*    padding: 0;*/
        /*    box-sizing: border-box;*/
        /*    font-family: 'Poppins', sans-serif;*/
        /*}*/

        .btn{
            position: relative;/*относительное позиционирование*/
            padding: 15px 20px;
            background: #fff;
            font-size: 18px;
            display: inline-block;/*отображать как строчно-блочный элемент*/
            text-decoration: none;
            color: #a52a2a;
            cursor: pointer;
            font-weight: 500;
            letter-spacing: 2px;/*расстояние между буквами*/
            text-transform: uppercase;
            transition: 0.5s;
        }
        #popup{
            position: fixed;/*фиксированное позиционирование*/
            top: -100%;/*прячем окно за пределы видимости*/
            left: 50%;/*позиция окна слева*/
            transform: translate(-50%,-50%);
            z-index: 1000;/*на верхний слой*/
            background: #fff;
            width: 450px;
            padding: 80px 50px 50px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.08);
            transition: 0.5s;
            visibility: hidden;/*скрываем окно*/
        }
        #popup.active{
            visibility: visible;/*показываем окно*/
            top: 50%;/*окно выдвигается сверху*/
        }
        #popup .content{
            position: relative;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;/*направление главной оси*/
        }
        #popup .content img{
            max-width: 80px;
        }
        #popup .content h2{
            font-size: 24px;
            font-weight: 500;
            color: #333;
            text-align: center;
        }
        #popup .content p{
            text-align: center;
            font-size: 16px;
            color: #333;
        }
        #popup .content .inputBox{
            position: relative;
            width: 100%;
            margin-top: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        #popup .content .inputBox input, #popup .content .inputBox .btn-submit{
            width: 100%;
            border: 1px solid rgba(0,0,0,0.2);
            padding: 15px;
            outline: none;
            font-size: 18px;
        }
        #popup .content .inputBox input[type="submit"],.btn-submit{
            max-width: 150px;
            background: #E57373;
            color: #fff;
            border: none;
            text-align: center;
        }
        .close{
            position: absolute;
            top: 30px;
            right: 30px;
            cursor: pointer;
        }
        .cbk-phone{
            display: none !important;
        }
    </style>
    <div id="popup">
        <div class="content">
            <h2>Рассчитать доставку до Вашего адреса.</h2>
            <div class="inputBox">
                <a class="btn-submit" href="#callbackwidget" onclick="popupToggle();">Рассчитать</a>
            </div>
        </div>
        <a class="close" onclick="popupToggle();" >✖</a>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded",function (){
            setTimeout(popupToggle, 10000);
        })
        function popupToggle(){
            const  popup = document.getElementById('popup');
            popup.classList.toggle('active');
        }
    </script>
<? require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>